#ifndef BIBLIO_H_INCLUDED
#define BIBLIO_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include "conio.h"
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdbool.h>
#include <windows.h>

#define MAX_PIEGES 20  // Nombre maximal de pieges
#define MAX_OISEAUX 4  // Nombre maximal d'oiseaux
#define MAX_MURS 40  // Nombre maximal de murs
#define MAX_CASSABLES 5  // Nombre maximal de blocs cassables
#define MAX_POUSSABLES 5 // Nombre maximal de blocs poussables

typedef struct
{
    int x;
    int y;
} Position;

typedef struct
{
    Position positionPiege;
} Piege;

typedef struct Oiseau
{
    Position positionOiseau;
} Oiseau;

typedef struct
{
    Position positionMur;
} Mur;

typedef struct
{
    Position positionCassable;
} Cassable;  // Nouveau type de bloc : le bloc cassable

typedef struct
{
    Position positionPoussable;
} Poussable;  // Nouveau type de bloc : le bloc cassable

typedef struct {

  Position Surprise;

} Surprise;

// Structure Snoopy
typedef struct
{
    int vie;
    int score[3];
    int scoreTot;
    Position position;
    Piege pieges[MAX_PIEGES];
    Oiseau oiseaux[MAX_OISEAUX];
    int nbOiseau;
    int nbPieges;
    Mur murs[MAX_MURS];  // Nouveau type de bloc : le mur
    int nbMurs;  // Nombre de murs
    int niveau;
    Cassable cassables[MAX_CASSABLES];  // Nouveau type de bloc : le bloc cassable
    int nbCassables;  // Nombre de blocs cassables
    int nbPoussable;
    Poussable poussable[MAX_POUSSABLES];
    int etat[MAX_POUSSABLES];
    Surprise surprise[2];
    int nbSurprise;

} Snoopy;


typedef struct
{
    Position position_balle;
    bool colli_balle;
    int x;
    int y;
} Balle;





void NbOiseau(Snoopy *joueur);
int deplacement(Snoopy *joueur,Balle *maBalle;);
void plateau(Snoopy *joueur,Balle *maBalle);
void SnoopyBille(Snoopy *joueur,Balle *maBalle);
void SnoopyPiege(Snoopy *joueur);
void changementDirectionBalle(Balle *maBalle);
void OiseauCollecte(Snoopy *joueur);
void regles();
void lecturemdp(Snoopy *joueur1,Balle *maBalle);
void Mort(Snoopy *joueur);
void menu();
void sauvegarde(Snoopy *joueur,Balle*maBalle);
void chargement(Snoopy*joueur,Balle*maBalle);
void afficherInfosJoueur(Snoopy *joueur);
void niveau2(Snoopy *joueur, Balle *maBalle);
int estSurMur(int x, int y, Mur *murs, int nbMurs);
void niveau3(Snoopy *joueur, Balle *maBalle);
void casserBlocCassable(Snoopy *joueur);
int estSurObstacle(int x, int y, Mur *murs, int nbMurs, Cassable *cassables, int nbCassables,Poussable*poussable,int nbPoussable);
void niveau4(Snoopy *joueur, Balle *maBalle);
void Pous(Snoopy *joueur);



#endif // BIBLIO_H_INCLUDED
