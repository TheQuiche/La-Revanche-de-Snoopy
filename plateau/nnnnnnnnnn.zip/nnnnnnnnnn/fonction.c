#include "biblio.h"
void menu()
{
    /*
    int choix;
    printf("1) Regles du jeu\n2) Lancer un nouveau jeu a partir du niveau 1\n3) Charger une partie\n4) Lancer directement un niveau via son Mot de passe\n5) Scores\n6) Quitter\n");

    scanf("%d", &choix);

    while (choix < 1 || choix > 6)
    {
        printf("Entrer une valeur entre 1 et 6\n");
        printf("1) Regles du jeu\n2) Lancer un nouveau jeu a partir du niveau 1\n3) Charger une partie\n4) Lancer directement un niveau via son Mot de passe\n5) Scores\n6) Quitter\n");
        scanf("%d", &choix);
    }

    switch (choix)
    {
    case 1:
        printf("Vous avez choisi regles du jeu\n");
        regles();
        break;
    case 2:
        printf("Vous avez choisi lancer un nouveau jeu a partir du niveau 1\n");

        while (joueur1.vie > 0)
        {
            plateau(&joueur1,&maBalle);
            afficherInfosJoueur(&joueur1);
            deplacement(&joueur1);
        }
        break;

    case 3:
        printf("Vous avez choisi charger une partie\n");
        chargement(&joueur1,&maBalle);
        while (joueur1.vie > 0)
        {
            plateau(&joueur1,&maBalle);
            afficherInfosJoueur(&joueur1);
            deplacement(&joueur1);
        }
        break;
    case 4:
        printf("Vous avez choisi lancer directement un niveau via son Mot de passe\n");
        lecturemdp(); // Si la fonction lecturemdp est d�finie
        break;
    case 5:
        printf("Vous avez choisi scores\n");
        break;
    case 6:
        printf("Vous avez choisi quitter\n");
        break;
    }*/
}

int estSurObstacle(int x, int y, Mur *murs, int nbMurs, Cassable *cassables, int nbCassables,Poussable*poussable,int nbPoussable)
{
    for (int m = 0; m < nbMurs; ++m)
    {
        if (x == murs[m].positionMur.x && y == murs[m].positionMur.y)
        {
            return 1;  // Le joueur est sur un mur
        }
    }

    for (int c = 0; c < nbCassables; ++c)
    {
        if (x == cassables[c].positionCassable.x && y == cassables[c].positionCassable.y)
        {
            return 1;  // Le joueur est sur un bloc cassable
        }
    }
    for (int c = 0; c < nbPoussable; ++c)
    {
        if (x == poussable[c].positionPoussable.x && y == poussable[c].positionPoussable.y)
        {
            return 1;  // Le joueur est sur un bloc cassable
        }
    }

    return 0;  // Le joueur n'est pas sur un mur ou un bloc cassable
}

void Mort(Snoopy *joueur)
{
    if(joueur->vie<+0)
    {
        printf("Vous etes mort ");
        menu();
    }

}

void NbOiseau(Snoopy *joueur)
{
    for (int o = 0; o < MAX_OISEAUX; ++o)
    {
        if (joueur->position.x == joueur->oiseaux[o].positionOiseau.x && joueur->position.y == joueur->oiseaux[o].positionOiseau.y)
        {
            printf("Vous avez atteint un oiseau !\n");
            joueur->nbOiseau++;
            joueur->oiseaux[o].positionOiseau.x = 0;
            joueur->oiseaux[o].positionOiseau.y = 0;
        }
    }
}

void casserBlocCassable(Snoopy *joueur)
{
    int x = joueur->position.x;
    int y = joueur->position.y;

    // V�rifier la proximit� du joueur avec les blocs cassables
    for (int c = 0; c < joueur->nbCassables; ++c)
    {
        int cx = joueur->cassables[c].positionCassable.x;
        int cy = joueur->cassables[c].positionCassable.y;

        if (abs(cx - x) <= 1 && abs(cy - y) <= 1)
        {
            // Le bloc cassable est � proximit� du joueur, le casser
            joueur->cassables[c].positionCassable.x = 0;
            joueur->cassables[c].positionCassable.y = 0;
            printf("Bloc cassable d�truit !\n");
            return;
        }
    }

    // Aucun bloc cassable � proximit�
    printf("Aucun bloc cassable � proximit�.\n");
}

void Pous(Snoopy *joueur)
{
    int x = joueur->position.x;
    int y = joueur->position.y;
    // V�rifier la proximit� du joueur avec les blocs cassables
    for (int c = 0; c < joueur->nbPoussable; ++c)
    {
        int cx = joueur->poussable[c].positionPoussable.x;
        int cy = joueur->poussable[c].positionPoussable.y;

        if ((abs(cx - x) <= 1 && abs(cy - y) <= 1) && joueur->etat[c]!=1)
        {
            if((joueur->position.x>joueur->poussable[c].positionPoussable.x) && (joueur->position.y==joueur->poussable[c].positionPoussable.y))
            {
                joueur->poussable[c].positionPoussable.x--;
                joueur->etat[c]=1;
            }
            if((joueur->position.x<joueur->poussable[c].positionPoussable.x) && (joueur->position.y==joueur->poussable[c].positionPoussable.y))
            {
                joueur->poussable[c].positionPoussable.x++;
                joueur->etat[c]=1;

            }
            if((joueur->position.x==joueur->poussable[c].positionPoussable.x) && (joueur->position.y<joueur->poussable[c].positionPoussable.y))
            {
                joueur->poussable[c].positionPoussable.y++;
                joueur->etat[c]=1;

            }
            if((joueur->position.x==joueur->poussable[c].positionPoussable.x) && (joueur->position.y>joueur->poussable[c].positionPoussable.y))
            {
                joueur->poussable[c].positionPoussable.y--;
                joueur->etat[c]=1;

            }
            return;
        }
    }

    // Aucun bloc cassable � proximit�
    printf("Aucun bloc cassable � proximit�.\n");
}


void deplacementBalle(Balle *maBalle)
{
    // D�placement en diagonale
    if (maBalle->x==1 && maBalle->y==1)
    {
        maBalle->position_balle.x += 1;
        maBalle->position_balle.y += 1;
    }
    else if (maBalle->x==(-1) && maBalle->y==1)
    {
        maBalle->position_balle.x -= 1;
        maBalle->position_balle.y += 1;
    }
    else if (maBalle->x==1 && maBalle->y==(-1))
    {
        maBalle->position_balle.x += 1;
        maBalle->position_balle.y -= 1;
    }
    else if (maBalle->x==(-1) && maBalle->y==(-1))
    {
        maBalle->position_balle.x -= 1;
        maBalle->position_balle.y -= 1;
    }

}

int deplacement(Snoopy *joueur, Balle *maBalle)
{
    printf("%c",0x01);

    int choix_deplacement;


    printf(" Position x : %d, Position y: %d\n",joueur->position.x, joueur->position.y);
    printf("Position de la balle y : %d , : %d \n",maBalle->position_balle.x+1,maBalle->position_balle.y+1);
    printf("Nb Oiseau : %d\n",joueur->nbOiseau);
    printf("Vie restante : %d\n",joueur->vie);
    printf("Choissisez entre 1 et 4\n");
    printf("1 - Avancer\n");
    printf("2 - Reculer\n");
    printf("3 - Monter\n");
    printf("4 - Descendre \n");
    printf("5 - Casser un bloc\n");
    printf("6 - Pousser un bloc\n");
    printf("s ou S - Sauvegarder \n");

    printf("Choix : ");

    choix_deplacement=_getch();
    int nouvellePositionX = joueur->position.x;
    int nouvellePositionY = joueur->position.y;
    switch (choix_deplacement)
    {
    case '1': // Avancer
        if(nouvellePositionX<20)
        {
            nouvellePositionX += 1;
            printf("Snoopy avance d'une unite vers la droite. Nouvelle position : (%d, %d)\n", nouvellePositionX, nouvellePositionY);
        }
        else
        {
            printf("Vous etes a la bordure");
            sleep(1);
        }
        break;
    case '2': // Reculer
        if (nouvellePositionX>1)
        {
            nouvellePositionX -= 1;
            printf("Snoopy recule d'une unite vers la gauche. Nouvelle position : (%d, %d)\n", nouvellePositionX, nouvellePositionY);


        }
        else
        {
            printf("Vous etes a la bordure");
            sleep(1);
        }

        break;
    case '3': // Monter
        if (nouvellePositionY>1)
        {
            nouvellePositionY -= 1;
            printf("Snoopy monte d'une unite vers le haut. Nouvelle position : (%d, %d)\n", nouvellePositionX, nouvellePositionY);
        }
        else
        {
            printf("Vous etes a la bordure");
        }
        break;
    case '4': // Descendre
        if (nouvellePositionY<10)
        {
            nouvellePositionY += 1;
            printf("Snoopy descend d'une unite vers le bas. Nouvelle position : (%d, %d)\n", nouvellePositionX, nouvellePositionY);
        }
        else
        {
            printf("Vous etes a la bordure");
            sleep(1);
        }
        break;
    case '5':
    {
        casserBlocCassable(joueur);
        break;  // Le reste du d�placement n'est pas ex�cut� apr�s avoir cass� le bloc
    }
    case '6':
    {
        Pous(joueur);
        break;  // Le reste du d�placement n'est pas ex�cut� apr�s avoir cass� le bloc
    }

    case 's':
        printf("Sauvegarder le niveau\n");
        sauvegarde(joueur,maBalle);
        break;
    case 'S':
        printf("Sauvegarder le niveau\n");
        sauvegarde(joueur,maBalle);
        break;
    default:
        printf("Choix invalide. Veuillez entrer un nombre entre 1 et 4, ou alors s ou S.\n");
        return -1; // Valeur de retour pour indiquer une erreur
    }

    if (nouvellePositionX >= 1 && nouvellePositionX <= 20 &&
            nouvellePositionY >= 1 && nouvellePositionY <= 10 &&
            !estSurObstacle(nouvellePositionX, nouvellePositionY, joueur->murs, joueur->nbMurs, joueur->cassables, joueur->nbCassables,joueur->poussable,joueur->nbPoussable))
    {
        joueur->position.x = nouvellePositionX;
        joueur->position.y = nouvellePositionY;
        printf("Nouvelle position : (%d, %d)\n", joueur->position.x, joueur->position.y);
        deplacementBalle(maBalle);
        changementDirectionBalle(maBalle);
    }
    else
    {
        printf("D�placement impossible. Vous ne pouvez pas aller sur un mur ou vous �tes � la bordure.\n");
        sleep(1);
    }

    NbOiseau(joueur);
    return 0;
}




int estSurMur(int x, int y, Mur *murs, int nbMurs)
{
    for (int m = 0; m < nbMurs; ++m)
    {
        if (x == murs[m].positionMur.x && y == murs[m].positionMur.y)
        {
            return 1;  // Le joueur est sur un mur
        }
    }
    return 0;  // Le joueur n'est pas sur un mur
}

void OiseauCollecte(Snoopy *joueur)
{
    if (joueur->nbOiseau == 4)
    {
        // Le joueur a collect� tous les oiseaux, passez au niveau sup�rieur
        printf("Felicitations! Vous avez collecte tous les oiseaux. Passez au niveau sup�rieur.\n");
        joueur->score[0] = 100;

    }
}

void changementDirectionBalle(Balle *maBalle)
{
    if (maBalle->position_balle.x==0 || maBalle->position_balle.x==9)
    {

        maBalle->x=maBalle->x*(-1);

    }
    else if (maBalle->position_balle.y==0 || maBalle->position_balle.y==19)
    {

        maBalle->y=maBalle->y*(-1);
    }
    else if (maBalle->position_balle.x==0 && maBalle->position_balle.y==0)
    {

        maBalle->x=maBalle->x*(-1);
        maBalle->y=maBalle->y*(-1);
    }
    else if (maBalle->position_balle.x==9 && maBalle->position_balle.y==19)
    {
        maBalle->x=maBalle->x*(-1);
        maBalle->y=maBalle->y*(-1);
    }
}


void SnoopyPiege(Snoopy *joueur)
{
    for (int p = 0; p < MAX_PIEGES; ++p)
    {
        if (joueur->position.x == joueur->pieges[p].positionPiege.x && joueur->position.y == joueur->pieges[p].positionPiege.y)
        {
            joueur->vie--;
            joueur->position.x = 2;

            joueur->position.y = 5;
        }
    }
    Mort(joueur);
}



void SnoopySurprise(Snoopy* joueur)
{
    for (int p = 0; p < 2; ++p)
    {
        if (joueur->position.x == joueur->surprise[p].Surprise.x && joueur->position.y == joueur->surprise[p].Surprise.y)
        {
            srand(time(NULL));
            int a = 0;
            int b = 0;
            a = rand() % (20 - 1 + 1) + 1;
            b = rand() % (10 - 1 + 1) + 1;
            joueur->position.x = a;
            joueur->position.y = b;
        }
    }
}

void SnoopyBille(Snoopy *joueur,Balle *maBalle)
{
    if (joueur->position.x==maBalle->position_balle.y+1 && joueur->position.y==maBalle->position_balle.x+1)
    {
        joueur->vie=0;
        Mort(joueur);
    }

}



void plateau(Snoopy *joueur,Balle *maBalle)
{




    system("cls");
    for (int k = 0; k < 10; ++k)
    {
        for (int j = 0; j < 1; ++j)
        {
            for (int i = 0; i < 20; ++i)
            {


                printf("%c%c%c%c%c%c", 0xC9, 0xCD, 0xCD, 0xCD, 0xCD, 0xBB);

            }

            for (int m = 0; m < 1; ++m)
            {
                for (int i = 0; i < 20; ++i)
                {

                    int isSnoopy = (i == joueur->position.x - 1 && k == joueur->position.y - 1) && joueur->vie > 0;
                    int isPiege = 0;
                    int isOiseau = 0;

                    for (int p = 0; p < joueur->nbPieges; ++p)
                    {
                        if (i == joueur->pieges[p].positionPiege.x - 1 && k == joueur->pieges[p].positionPiege.y - 1)
                        {
                            isPiege = 1;
                            break;
                        }
                    }

                    for (int o = 0; o < MAX_OISEAUX; ++o)
                    {
                        if (i == joueur->oiseaux[o].positionOiseau.x - 1 && k == joueur->oiseaux[o].positionOiseau.y - 1)
                        {
                            isOiseau = 1;
                            break;
                        }
                    }


                    if (isSnoopy)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x01, 0x20, 0x20, 0xBA);
                    }
                    else if(i == maBalle->position_balle.y && k == maBalle->position_balle.x)
                    {
                        printf("%c%co%c%c%c", 0xBA, 0x20, 0x20, 0x20, 0xBA);
                    }
                    else if (isPiege)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0X5, 0x20, 0x20, 0xBA);
                    }
                    else if (isOiseau)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x3E, 0x20, 0x20, 0xBA);
                    }
                    else
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x20, 0x20, 0x20, 0xBA);
                    }
                }
            }

            for (int i = 0; i < 20; ++i)
            {

                printf("%c%c%c%c%c%c", 0xC8, 0xCD, 0xCD, 0xCD, 0xCD, 0xBC);

            }
            printf("\n");
        }

    }
    SnoopyBille(joueur,maBalle);
    SnoopyPiege(joueur);
    OiseauCollecte(joueur);

}




void regles()
{
    FILE*fichier=NULL;
    char ligne[1024];

    fichier=fopen("regles.txt","r");
    if (fichier == NULL)
    {
        printf("Impossible d'ouvrir le fichier.\n");
    }

    while (fgets(ligne, sizeof(ligne), fichier) != NULL)
    {
        printf("%s", ligne);
    }
}

void lecturemdp(Snoopy *joueur1,Balle *maBalle)
{
    char *tab[30];
    char mdp[30];
    char tempo[20];
    int nbligne=0;
    FILE*fichier=NULL;
    fichier=fopen("niveaumdp.txt","r");
    if (fichier == NULL)
    {
        printf("Impossible d'ouvrir le fichier.\n");
        exit (1);
    }
    printf("Saisir le mot de passe du niveau auquel vous voulez acceder\n");
    scanf("%s",mdp);
    while (fgets(tempo, sizeof(tempo), fichier) != NULL)
    {
        tab[nbligne] = strdup(tempo);
        nbligne++;
    }
    fclose(fichier);
    for (int i = 0; i < nbligne; i++)
    {
        tab[i][strlen(tab[i]) - 1] = '\0';
        if (strcmp(mdp, tab[i]) == 0)
        {
            printf("Mot de passe correct.\n");
            if (i == 0)
            {
                printf("Vous allez au niveau 1\n");
                while (joueur1->vie > 0)
                {
                    plateau(joueur1,maBalle);
                    afficherInfosJoueur(joueur1);
                    deplacement(joueur1,maBalle);
                    joueur1->niveau=1;
                }
            }
            else if (i == 1)
            {
                printf("Vous allez au niveau 2\n");
                while (joueur1->vie > 0)
                {
                    niveau2(joueur1,maBalle);
                    afficherInfosJoueur(joueur1);
                    deplacement(joueur1,maBalle);
                    joueur1->niveau=2;

                }
            }
            else if (i == 2)
            {
                printf("Vous allez au niveau 3\n");
                while (joueur1->vie > 0)
                {
                    niveau3(joueur1,maBalle);
                    afficherInfosJoueur(joueur1);
                    deplacement(joueur1,maBalle);
                    joueur1->niveau=3;

                }
            }
            else if (i == 3)
            {
                printf("Vous allez au niveau 4\n");
                while (joueur1->vie > 0)
                {
                    niveau4(joueur1,maBalle);
                    afficherInfosJoueur(joueur1);
                    deplacement(joueur1,maBalle);
                    joueur1->niveau=4;

                }
            }

        }
        else
        {
            printf("Mot de passe incorrecte\n");
        }
    }
    for (int j = 0; j < nbligne; j++)
    {
        free(tab[j]);
    }
}

void sauvegarde(Snoopy *joueur,Balle*maBalle)
{
    FILE*fichier;
    char nom[30];
    int choix;
    printf("Comment voulez vous appeler votre fichier\n");
    scanf("%s",nom);
    do
    {
        printf("1) Sauvegarder en fichier binaire\n2)Sauvegarder en fichier texte\n");
        scanf("%d",&choix);
    }
    while(choix<1 || choix>2);
    if(choix==2)
    {
        strcat(nom,".txt");
        fichier=fopen(nom,"w");
        if(fichier==NULL)
        {
            printf("Impossibe douvrir le fichier\n");
        }
        fprintf(fichier,"%d\n",joueur->niveau);
        fprintf(fichier,"%d\n" "%d\n",joueur->position.x,joueur->position.y);
        fprintf(fichier,"%d\n",joueur->nbPieges);
        fprintf(fichier,"%d\n",joueur->vie);
        fprintf(fichier,"%d\n",joueur->nbOiseau);

        for(int i=0; i<joueur->nbPieges; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->pieges[i].positionPiege.x,joueur->pieges[i].positionPiege.y);

        }
        for(int i=0; i<4; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->oiseaux[i].positionOiseau.x,joueur->oiseaux[i].positionOiseau.y);
        }
        fprintf(fichier,"%d\n" "%d\n",maBalle->position_balle.x,maBalle->position_balle.y);

        for(int i=0; i<joueur->nbMurs; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->murs[i].positionMur.x,joueur->murs[i].positionMur.y);
        }
        for(int i=0; i<joueur->nbCassables; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->cassables[i].positionCassable.x,joueur->cassables[i].positionCassable.y);
        }
        for(int i=0; i<joueur->nbPoussable; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->poussable[i].positionPoussable.x,joueur->poussable[i].positionPoussable.y);
            fprintf(fichier,"%d\n",joueur->etat[i]);
        }

        fclose(fichier);
    }
    if(choix==1)
    {
        strcat(nom,".bin");
        fichier=fopen(nom,"wb");
        if(fichier==NULL)
        {
            printf("Impossibe douvrir le fichier\n");
        }
        fprintf(fichier,"%d\n",joueur->niveau);

        fprintf(fichier,"%d\n" "%d\n",joueur->position.x,joueur->position.y);
        fprintf(fichier,"%d\n",joueur->nbPieges);
        fprintf(fichier,"%d\n",joueur->vie);
        fprintf(fichier,"%d\n",joueur->nbOiseau);

        for(int i=0; i<joueur->nbPieges; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->pieges[i].positionPiege.x,joueur->pieges[i].positionPiege.y);
        }
        for(int i=0; i<4; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->oiseaux[i].positionOiseau.x,joueur->oiseaux[i].positionOiseau.y);
        }
        fprintf(fichier,"%d\n" "%d\n",maBalle->position_balle.x,maBalle->position_balle.y);
        for(int i=0; i<joueur->nbMurs; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->murs[i].positionMur.x,joueur->murs[i].positionMur.y);
        }
        for(int i=0; i<joueur->nbCassables; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->cassables[i].positionCassable.x,joueur->cassables[i].positionCassable.y);
        }
        for(int i=0; i<joueur->nbPoussable; i++)
        {
            fprintf(fichier,"%d\n""%d\n",joueur->poussable[i].positionPoussable.x,joueur->poussable[i].positionPoussable.y);
            fprintf(fichier,"%d\n",joueur->etat[i]);

        }

        fclose(fichier);
    }
}

void chargement(Snoopy*joueur,Balle*maBalle)
{
    FILE*fichier;
    char nom[30];
    int choix;
    printf("Saisir le nom du fichier de chargement\n");
    scanf("%s",nom);
    do
    {
        printf("1) Charger un fichier binaire\n2)Charger un fichier texte\n");
        scanf("%d",&choix);
    }
    while(choix<1 || choix>2);
    if(choix==2)
    {
        strcat(nom,".txt");
        fichier=fopen(nom,"r");
        if(fichier==NULL)
        {
            printf("Impossibe douvrir le fichier\n");
        }
        else
        {
            while(!feof(fichier))
            {
                fscanf(fichier,"%d\n",&joueur->niveau);

                fscanf(fichier,"%d\n" "%d\n",&joueur->position.x,&joueur->position.y);
                fscanf(fichier,"%d\n",&joueur->nbPieges);
                fscanf(fichier,"%d\n",&joueur->vie);
                fscanf(fichier,"%d\n",&joueur->nbOiseau);

                for(int i=0; i<joueur->nbPieges; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->pieges[i].positionPiege.x,&joueur->pieges[i].positionPiege.y);
                }
                for(int i=0; i<4; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->oiseaux[i].positionOiseau.x,&joueur->oiseaux[i].positionOiseau.y);
                }

                fscanf(fichier,"%d\n" "%d\n",&maBalle->position_balle.x,&maBalle->position_balle.y);
                for(int i=0; i<joueur->nbMurs; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->murs[i].positionMur.x,&joueur->murs[i].positionMur.y);
                }
                for(int i=0; i<joueur->nbCassables; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->cassables[i].positionCassable.x,&joueur->cassables[i].positionCassable.y);
                }
                for(int i=0; i<joueur->nbPoussable; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->poussable[i].positionPoussable.x,&joueur->poussable[i].positionPoussable.y);
                    fscanf(fichier,"%d\n",&joueur->etat[i]);

                }

                printf("La position de Snoopy x est %d et la position y est %d",joueur->position.x,joueur->position.y);
            }
            fclose(fichier);
        }
    }
    else if(choix==1)
    {
        strcat(nom,".bin");
        fichier=fopen(nom,"rb");
        if(fichier==NULL)
        {
            printf("Impossibe douvrir le fichier\n");
        }
        else
        {
            while(!feof(fichier))
            {
                fscanf(fichier,"%d\n",&joueur->niveau);

                fscanf(fichier,"%d\n" "%d\n",&joueur->position.x,&joueur->position.y);
                fscanf(fichier,"%d\n",&joueur->nbPieges);
                fscanf(fichier,"%d\n",&joueur->vie);
                fscanf(fichier,"%d\n",&joueur->nbOiseau);

                for(int i=0; i<joueur->nbPieges; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->pieges[i].positionPiege.x,&joueur->pieges[i].positionPiege.y);

                }
                for(int i=0; i<4; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->oiseaux[i].positionOiseau.x,&joueur->oiseaux[i].positionOiseau.y);
                }
                fscanf(fichier,"%d\n" "%d\n",&maBalle->position_balle.x,&maBalle->position_balle.y);

                for(int i=0; i<joueur->nbMurs; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->murs[i].positionMur.x,&joueur->murs[i].positionMur.y);
                }
                for(int i=0; i<joueur->nbCassables; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->cassables[i].positionCassable.x,&joueur->cassables[i].positionCassable.y);
                }
                for(int i=0; i<joueur->nbPoussable; i++)
                {
                    fscanf(fichier,"%d\n""%d\n",&joueur->poussable[i].positionPoussable.x,&joueur->poussable[i].positionPoussable.y);
                    fscanf(fichier,"%d\n",&joueur->etat[i]);

                }
                printf("La position de Snoopy x est %d et la position y est %d",joueur->position.x,joueur->position.y);

            }
            fclose(fichier);
        }
    }

}
void afficherInfosJoueur(Snoopy *joueur)
{
    printf("Vie : %d\n", joueur->vie);
    printf("Oiseaux : %d\n", joueur->nbOiseau);
    printf("score : %d\n", joueur->scoreTot);
}
void niveau2(Snoopy *joueur, Balle *maBalle)
{
    system("cls");
    for (int k = 0; k < 10; ++k)
    {
        for (int j = 0; j < 1; ++j)
        {
            for (int i = 0; i < 20; ++i)
            {
                printf("%c%c%c%c%c%c", 0xC9, 0xCD, 0xCD, 0xCD, 0xCD, 0xBB);
            }

            for (int m = 0; m < 1; ++m)
            {
                for (int i = 0; i < 20; ++i)
                {
                    int isSnoopy = (i == joueur->position.x - 1 && k == joueur->position.y - 1) && joueur->vie > 0;
                    int isPiege = 0;
                    int isOiseau = 0;
                    int isMur = 0;

                    for (int p = 0; p < joueur->nbPieges; ++p)
                    {
                        if (i == joueur->pieges[p].positionPiege.x - 1 && k == joueur->pieges[p].positionPiege.y - 1)
                        {
                            isPiege = 1;
                            break;
                        }
                    }

                    for (int m = 0; m < joueur->nbMurs; ++m)
                    {
                        if (i == joueur->murs[m].positionMur.x - 1 && k == joueur->murs[m].positionMur.y - 1)
                        {
                            isMur = 1;
                            break;
                        }
                    }

                    for (int o = 0; o < MAX_OISEAUX; ++o)
                    {
                        if (i == joueur->oiseaux[o].positionOiseau.x - 1 && k == joueur->oiseaux[o].positionOiseau.y - 1)
                        {
                            isOiseau = 1;
                            break;
                        }
                    }

                    if (isSnoopy)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x01, 0x20, 0x20, 0xBA);
                    }
                    else if (i == maBalle->position_balle.y  && k == maBalle->position_balle.x )
                    {
                        printf("%c%co%c%c%c", 0xBA, 0x20, 0x20, 0x20, 0xBA);
                    }
                    else if (isPiege)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0X5, 0x20, 0x20, 0xBA);
                    }
                    else if (isOiseau)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x3E, 0x20, 0x20, 0xBA);
                    }
                    else if (isMur)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x4D, 0x20, 0x20, 0xBA); // Afficher le mur
                    }
                    else
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x20, 0x20, 0x20, 0xBA);
                    }
                }
            }

            for (int i = 0; i < 20; ++i)
            {
                printf("%c%c%c%c%c%c", 0xC8, 0xCD, 0xCD, 0xCD, 0xCD, 0xBC);
            }
            printf("\n");
        }
    }
    SnoopyBille(joueur, maBalle);
    SnoopyPiege(joueur);
    OiseauCollecte(joueur);
}

void niveau3(Snoopy *joueur, Balle *maBalle)
{
    system("cls");
    for (int k = 0; k < 10; ++k)
    {
        for (int j = 0; j < 1; ++j)
        {
            for (int i = 0; i < 20; ++i)
            {
                printf("%c%c%c%c%c%c", 0xC9, 0xCD, 0xCD, 0xCD, 0xCD, 0xBB);
            }

            for (int m = 0; m < 1; ++m)
            {
                for (int i = 0; i < 20; ++i)
                {
                    int isSnoopy = (i == joueur->position.x - 1 && k == joueur->position.y - 1) && joueur->vie > 0;
                    int isPiege = 0;
                    int isOiseau = 0;
                    int isMur = 0;
                    int isCassable = 0;

                    for (int p = 0; p < joueur->nbPieges; ++p)
                    {
                        if (i == joueur->pieges[p].positionPiege.x - 1 && k == joueur->pieges[p].positionPiege.y - 1)
                        {
                            isPiege = 1;
                            break;
                        }
                    }

                    for (int m = 0; m < joueur->nbMurs; ++m)
                    {
                        if (i == joueur->murs[m].positionMur.x - 1 && k == joueur->murs[m].positionMur.y - 1)
                        {
                            isMur = 1;
                            break;
                        }
                    }

                    for (int c = 0; c < joueur->nbCassables; ++c)
                    {
                        if (i == joueur->cassables[c].positionCassable.x - 1 && k == joueur->cassables[c].positionCassable.y - 1)
                        {
                            isCassable = 1;
                            break;
                        }
                    }

                    for (int o = 0; o < MAX_OISEAUX; ++o)
                    {
                        if (i == joueur->oiseaux[o].positionOiseau.x - 1 && k == joueur->oiseaux[o].positionOiseau.y - 1)
                        {
                            isOiseau = 1;
                            break;
                        }
                    }

                    if (isSnoopy)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x01, 0x20, 0x20, 0xBA);
                    }
                    else if (i == maBalle->position_balle.y  && k == maBalle->position_balle.x )
                    {
                        printf("%c%co%c%c%c", 0xBA, 0x20, 0x20, 0x20, 0xBA);
                    }
                    else if (isPiege)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0X5, 0x20, 0x20, 0xBA);
                    }
                    else if (isOiseau)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x3E, 0x20, 0x20, 0xBA);
                    }
                    else if (isMur)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x4D, 0x20, 0x20, 0xBA); // Afficher le mur
                    }
                    else if (isCassable)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x34, 0x20, 0x20, 0xBA); // Afficher le bloc cassable
                    }
                    else
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x20, 0x20, 0x20, 0xBA);
                    }
                }
            }

            for (int i = 0; i < 20; ++i)
            {
                printf("%c%c%c%c%c%c", 0xC8, 0xCD, 0xCD, 0xCD, 0xCD, 0xBC);
            }
            printf("\n");
        }
    }
    SnoopyBille(joueur, maBalle);
    SnoopyPiege(joueur);
    OiseauCollecte(joueur);
}

void niveau4(Snoopy *joueur, Balle *maBalle)
{
    system("cls");
    for (int k = 0; k < 10; ++k)
    {
        for (int j = 0; j < 1; ++j)
        {
            for (int i = 0; i < 20; ++i)
            {
                printf("%c%c%c%c%c%c", 0xC9, 0xCD, 0xCD, 0xCD, 0xCD, 0xBB);
            }

            for (int m = 0; m < 1; ++m)
            {
                for (int i = 0; i < 20; ++i)
                {
                    int isSnoopy = (i == joueur->position.x - 1 && k == joueur->position.y - 1) && joueur->vie > 0;
                    int isPiege = 0;
                    int isOiseau = 0;
                    int isMur = 0;
                    int isCassable = 0;
                    int isPoussable=0;
                    int isSurprise = 0;

                    for (int p = 0; p < joueur->nbPieges; ++p)
                    {
                        if (i == joueur->pieges[p].positionPiege.x - 1 && k == joueur->pieges[p].positionPiege.y - 1)
                        {
                            isPiege = 1;
                            break;
                        }
                    }

                    for (int m = 0; m < joueur->nbMurs; ++m)
                    {
                        if (i == joueur->murs[m].positionMur.x - 1 && k == joueur->murs[m].positionMur.y - 1)
                        {
                            isMur = 1;
                            break;
                        }
                    }

                    for (int c = 0; c < joueur->nbCassables; ++c)
                    {
                        if (i == joueur->cassables[c].positionCassable.x - 1 && k == joueur->cassables[c].positionCassable.y - 1)
                        {
                            isCassable = 1;
                            break;
                        }
                    }
                    for (int l = 0; l < joueur->nbPoussable; l++)
                    {
                        if (i == joueur->poussable[l].positionPoussable.x - 1 && k == joueur->poussable[l].positionPoussable.y - 1)
                        {
                            isPoussable = 1;
                            break;
                        }
                    }

                    for (int w = 0; w < joueur->nbSurprise; ++w)
                    {
                        if (i == joueur->surprise[w].Surprise.x - 1 && k == joueur->surprise[w].Surprise.y - 1)
                        {
                            isSurprise = 1;
                            break;
                        }
                    }
                     for (int p = 0; p < joueur->nbPieges; ++p)
                    {
                        if (i == joueur->pieges[p].positionPiege.x - 1 && k == joueur->pieges[p].positionPiege.y - 1)
                        {
                            isPiege = 1;
                            break;
                        }
                    }

                    if (isSnoopy)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x01, 0x20, 0x20, 0xBA);
                    }
                    else if (i == maBalle->position_balle.y  && k == maBalle->position_balle.x )
                    {
                        printf("%c%co%c%c%c", 0xBA, 0x20, 0x20, 0x20, 0xBA);
                    }
                    else if (isPiege)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0X5, 0x20, 0x20, 0xBA);
                    }
                    else if (isOiseau)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x3E, 0x20, 0x20, 0xBA);
                    }
                    else if (isMur)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x4D, 0x20, 0x20, 0xBA); // Afficher le mur
                    }
                    else if (isCassable)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x34, 0x20, 0x20, 0xBA); // Afficher le bloc cassable
                    }
                    else if (isPoussable)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x35, 0x20, 0x20, 0xBA); // Afficher le bloc poussable
                    }
                    else if (isSurprise)
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x3F, 0x20, 0x20, 0xBA); // Afficher le bloc Surprise
                    }
                    else
                    {
                        printf("%c%c%c%c%c%c", 0xBA, 0x20, 0x20, 0x20, 0x20, 0xBA);
                    }
                }
            }

            for (int i = 0; i < 20; ++i)
            {
                printf("%c%c%c%c%c%c", 0xC8, 0xCD, 0xCD, 0xCD, 0xCD, 0xBC);
            }
            printf("\n");
        }
    }
    SnoopyBille(joueur, maBalle);
    SnoopyPiege(joueur);
    SnoopySurprise(joueur);
    OiseauCollecte(joueur);
}
