#include "biblio.h"

int main()
{
    Snoopy joueur1;
    Balle maBalle;
    maBalle.position_balle.x=5;
    maBalle.position_balle.y=5;
    maBalle.x=1;
    maBalle.y=1;
    joueur1.vie = 3;
    joueur1.score[0] = 100;
    joueur1.score[1] = 200;
    joueur1.score[2] = 50;
    joueur1.scoreTot = joueur1.score[0] + joueur1.score[1] + joueur1.score[2];
    joueur1.nbOiseau = 0;
    joueur1.position.x = 2;
    joueur1.position.y = 5;
    joueur1.nbPieges = 14;
    joueur1.pieges[0].positionPiege.x = 10;
    joueur1.pieges[0].positionPiege.y = 4;

    joueur1.pieges[1].positionPiege.x = 1;
    joueur1.pieges[1].positionPiege.y = 8;
    joueur1.pieges[2].positionPiege.x = 15;
    joueur1.pieges[2].positionPiege.y = 4;

    joueur1.oiseaux[0].positionOiseau.x = 1;
    joueur1.oiseaux[0].positionOiseau.y = 1;

    joueur1.oiseaux[1].positionOiseau.x = 20;
    joueur1.oiseaux[1].positionOiseau.y = 1;

    joueur1.oiseaux[2].positionOiseau.x = 1;
    joueur1.oiseaux[2].positionOiseau.y = 10;

    joueur1.oiseaux[3].positionOiseau.x = 20;
    joueur1.oiseaux[3].positionOiseau.y = 10;
    joueur1.nbMurs = 1;
    joueur1.murs[0].positionMur.x = 10;  // Exemple de position du mur
    joueur1.murs[0].positionMur.y = 5;
    joueur1.nbCassables= 3;
    joueur1.cassables[0].positionCassable.x = 10;
    joueur1.cassables[0].positionCassable.y = 6;
    joueur1.cassables[1].positionCassable.x = 11;
    joueur1.cassables[1].positionCassable.y = 6;
    joueur1.cassables[2].positionCassable.x = 5;
    joueur1.cassables[2].positionCassable.y = 9;
    joueur1.nbPoussable=2;
    joueur1.poussable[0].positionPoussable.x=4;
    joueur1.poussable[0].positionPoussable.y=3;
    joueur1.poussable[1].positionPoussable.x=7;
    joueur1.poussable[1].positionPoussable.y=7;
    joueur1.etat[0]=0;
    joueur1.etat[1]=0;
    joueur1.nbSurprise = 2;
    joueur1.surprise[0].Surprise.x=2;
    joueur1.surprise[0].Surprise.y=2;
    joueur1.surprise[1].Surprise.x=17;
    joueur1.surprise[1].Surprise.y=9;
    int choix;

    printf("1) Regles du jeu\n2) Lancer un nouveau jeu a partir du niveau 1\n3) Charger une partie\n4) Lancer directement un niveau via son Mot de passe\n5) Scores\n6) Quitter\n");

    scanf("%d", &choix);

    while (choix < 1 || choix > 6)
    {
        printf("Entrer une valeur entre 1 et 6\n");
        printf("1) Regles du jeu\n2) Lancer un nouveau jeu a partir du niveau 1\n3) Charger une partie\n4) Lancer directement un niveau via son Mot de passe\n5) Scores\n6) Quitter\n");
        scanf("%d", &choix);
    }

    switch (choix)
    {
    case 1:
        printf("Vous avez choisi regles du jeu\n");
        regles();
        break;
    case 2:
        printf("Vous avez choisi lancer un nouveau jeu a partir du niveau 1\n");

        while (joueur1.vie > 0)
        {

            joueur1.niveau=1;
            plateau(&joueur1,&maBalle);
            afficherInfosJoueur(&joueur1);
            deplacement(&joueur1,&maBalle);
        }


        break;

    case 3:
        printf("Vous avez choisi charger une partie\n");
        chargement(&joueur1,&maBalle);
        while (joueur1.vie > 0)
        {
            if(joueur1.niveau==1)
            {Snoopy joueur1;
    Balle maBalle;
    maBalle.position_balle.x=5;
    maBalle.position_balle.y=5;
    maBalle.x=1;
    maBalle.y=1;
    joueur1.vie = 3;
    joueur1.score[0] = 100;
    joueur1.score[1] = 200;
    joueur1.score[2] = 50;
    joueur1.scoreTot = joueur1.score[0] + joueur1.score[1] + joueur1.score[2];
    joueur1.nbOiseau = 0;
    joueur1.position.x = 2;
    joueur1.position.y = 5;
    joueur1.nbPieges = 14;
    joueur1.pieges[0].positionPiege.x = 10;
    joueur1.pieges[0].positionPiege.y = 4;

    joueur1.pieges[1].positionPiege.x = 1;
    joueur1.pieges[1].positionPiege.y = 8;
    joueur1.pieges[2].positionPiege.x = 15;
    joueur1.pieges[2].positionPiege.y = 4;
    joueur1.pieges[3].positionPiege.x = 14;
    joueur1.pieges[3].positionPiege.y = 6 ;

    joueur1.pieges[4].positionPiege.x = 9;
    joueur1.pieges[4].positionPiege.y = 9;

    joueur1.pieges[5].positionPiege.x = 18;
    joueur1.pieges[5].positionPiege.y = 15;

    joueur1.pieges[6].positionPiege.x = 13;
    joueur1.pieges[6].positionPiege.y = 4;

    joueur1.pieges[7].positionPiege.x = 20;
    joueur1.pieges[7].positionPiege.y = 15;

    joueur1.pieges[8].positionPiege.x = 3;
    joueur1.pieges[8].positionPiege.y = 14;

    joueur1.pieges[9].positionPiege.x = 7;
    joueur1.pieges[9].positionPiege.y = 5;

    joueur1.pieges[10].positionPiege.x = 10 ;
    joueur1.pieges[10].positionPiege.y = 2;

    joueur1.pieges[11].positionPiege.x = 2;
    joueur1.pieges[11].positionPiege.y = 9;

    joueur1.pieges[12].positionPiege.x = 1;
    joueur1.pieges[12].positionPiege.y = 4;

    joueur1.pieges[13].positionPiege.x = 5;
    joueur1.pieges[13].positionPiege.y = 1;

    joueur1.oiseaux[0].positionOiseau.x = 1;
    joueur1.oiseaux[0].positionOiseau.y = 1;

    joueur1.oiseaux[1].positionOiseau.x = 20;
    joueur1.oiseaux[1].positionOiseau.y = 1;

    joueur1.oiseaux[2].positionOiseau.x = 1;
    joueur1.oiseaux[2].positionOiseau.y = 10;

    joueur1.oiseaux[3].positionOiseau.x = 20;
    joueur1.oiseaux[3].positionOiseau.y = 10;
                plateau(&joueur1,&maBalle);
                afficherInfosJoueur(&joueur1);
                deplacement(&joueur1);

            }
            if(joueur1.niveau==2)
            {
                niveau2(&joueur1,&maBalle);
                afficherInfosJoueur(&joueur1);
                deplacement(&joueur1);
            }
            if(joueur1.niveau==3)
            {
                niveau3(&joueur1,&maBalle);
                afficherInfosJoueur(&joueur1);
                deplacement(&joueur1);
            }
            if(joueur1.niveau==4)
            {
                niveau4(&joueur1,&maBalle);
                afficherInfosJoueur(&joueur1);
                deplacement(&joueur1);
            }

        }
        break;
    case 4:
        printf("Vous avez choisi lancer directement un niveau via son Mot de passe\n");
        lecturemdp(&joueur1,&maBalle); // Si la fonction lecturemdp est d�finie
        break;
    case 5:
        printf("Vous avez choisi scores\n");
        break;
    case 6:
        printf("Vous avez choisi quitter\n");
        return 0;
        break;
    }



    return 0;
}
